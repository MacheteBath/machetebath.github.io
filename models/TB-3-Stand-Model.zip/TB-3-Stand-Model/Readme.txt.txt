====================================================
ROLAND AIRA TB-3 ERGONOMIC DESKTOP STAND
Designed by MacheteBath
====================================================

A custom-engineered desktop riser for the Roland Aira TB-3. 
Designed to improve screen viewing angle and rear-cable access.

FILE CONTENTS:
- TB-3 Stand-Beam.3mf (High-fidelity project file)
- TB-3 Stand-Left (High-fidelity project file)
- TB-3 Stand-Right (High-fidelity project file)
- README.txt (This instruction file)

The "beams" will need to be printed x3 possibly with supports. (i just pulled them out with pliers after.

I don't remember the screw size but the holes are about 4 or 5 mm (could glue or print plugs alternatively)

OFFICIAL SITE: https://machetebath.github.io
CONTACT: machetebath@gmail.com

(c) 2026 MacheteBath. Provided for personal, non-commercial use.
====================================================